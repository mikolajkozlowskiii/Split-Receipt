var searchData=
[
  ['loginmodel',['LoginModel',['../class_split___receipt_1_1_areas_1_1_identity_1_1_pages_1_1_account_1_1_login_model.html',1,'Split_Receipt::Areas::Identity::Pages::Account']]]
];
