var searchData=
[
  ['the_20mit_20license_20_28mit_29',['The MIT License (MIT)',['../md__split-_receipt_wwwroot_lib_jquery-validation__l_i_c_e_n_s_e.html',1,'']]]
];
