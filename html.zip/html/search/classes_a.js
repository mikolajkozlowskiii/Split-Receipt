var searchData=
[
  ['user_5fgroup',['User_Group',['../class_split___receipt_1_1_models_1_1_user___group.html',1,'Split_Receipt::Models']]],
  ['usergrouprequest',['UserGroupRequest',['../class_split___receipt_1_1_payload_1_1_user_group_request.html',1,'Split_Receipt::Payload']]],
  ['usergroupresponse',['UserGroupResponse',['../class_split___receipt_1_1_payload_1_1_user_group_response.html',1,'Split_Receipt::Payload']]]
];
